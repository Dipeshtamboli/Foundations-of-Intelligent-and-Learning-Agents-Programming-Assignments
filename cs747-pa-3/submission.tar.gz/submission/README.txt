How to run the code:
-I have created a tasks.sh file which can be run and generate all the required plots for the tasks.
-all_functions.py has the class and all the required functions.
-task_runner.py runs the algorithm and plot the graph.
-additional_plots.py is there to generate additional plots.